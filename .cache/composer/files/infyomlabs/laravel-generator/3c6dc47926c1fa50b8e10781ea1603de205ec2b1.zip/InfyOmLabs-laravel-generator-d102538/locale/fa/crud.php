<?php

return [

    'add_new'      => 'اضافه',
    'cancel'       => 'لغو',
    'save'         => 'ذخیره',
    'edit'         => 'ویرایش',
    'detail'       => 'جزئیات',
    'back'         => 'بازگشت',
    'action'       => 'عملیات',
    'id'           => 'شناسه',
    'created_at'   => 'ایجاد شده در',
    'updated_at'   => 'به روز شده در',
    'deleted_at'   => 'حذف شده در',
    'are_you_sure' => 'آیا مطمئن هستید؟',
];

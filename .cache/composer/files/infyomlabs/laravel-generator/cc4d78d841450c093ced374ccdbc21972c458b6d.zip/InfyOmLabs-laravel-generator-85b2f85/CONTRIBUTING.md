# InfyOm Generator Contribution Guide

Thank you for considering contributing to the InfyOm Generator!

#### Coding Style
As this package is related to laravel, we are follows the PSR-2 coding standard and the PSR-4 autoloading standard.

#### StyleCI
We've integrated StyleCI. So when you submit a PR, it will automatically suggest the fix of styling. Fix it and re-submit the PR if needed.

#### Pull Requests
Please make all pull requests to the `develop` branch of the project.

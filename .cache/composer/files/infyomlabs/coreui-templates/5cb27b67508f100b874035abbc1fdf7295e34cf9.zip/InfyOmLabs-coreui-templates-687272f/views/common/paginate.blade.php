<div class="row">
    {!! $records->render() !!}
</div>
